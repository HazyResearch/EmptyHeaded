package jpype.exc;

public class ParentTestException extends java.lang.Exception {
  }