package jpype.attr;

public class TestOverloadC extends TestOverloadB {
    public String foo(int i) {
        return "foo(int) in C: " + i;
    }
}
